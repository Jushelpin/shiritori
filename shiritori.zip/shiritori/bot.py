from discord.ext import commands

from config import config
from cogs import game_cog


bot = commands.Bot(command_prefix=config.PREFIX)

@bot.event
async def on_ready():
    print(f"Ready. Client-ID: {bot.user.id}.")

bot.add_cog(game_cog.GameCog(bot))

bot.run(config.TOKEN)
