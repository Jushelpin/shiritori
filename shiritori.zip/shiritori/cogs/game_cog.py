from discord.ext import commands

from config import config

class GameCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
    @commands.Cog.listener()
    async def on_message(self, message):
        if message.channel.id == config.CHANNEL:
            history = await message.channel.history(limit=2).flatten()
            previous = history[-1]
            first_letter = message.content[0]
            if first_letter != previous.content[-1]:
                log_channel = self.bot.get_channel(config.LOG_CHANNEL)
                if log_channel:
                    await log_channel.send(f"Deleted {message.content} which was sent by {str(message.author)}")
                await message.delete()